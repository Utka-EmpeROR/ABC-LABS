//------------------------------------------------------------------------------
// Film.cpp - содержит процедуры связанные с обработкой обобщенного фильма
// и создания произвольного фильма
//------------------------------------------------------------------------------
#include <iostream>
#include <string>
#include "DocumentalFilm.h"
#include "GameFilm.h"
#include "Cartoon.h"

//------------------------------------------------------------------------------
// Ввод параметров обобщенного фильма из файла
Film* Film::StaticIn(ifstream &ifst) {
    int k,n;
    ifst >> k >> n;
    string name;
    getline(ifst,name);
    Film* film = nullptr;
    switch(k) {
        case 1:
            film = new GameFilm;
            break;
        case 2:
            film = new Cartoon;
            break;
        case 3:
            film = new DocumentalFilm;
            break;
    }
    if(film== nullptr){
        return film;
    }
    film->In(ifst);
    film->name= name;
    film->releaseDate=n;
    film->uselessNumber =(double)n/(double)name.length();
    return film;
}
void Film::Out(ofstream &ofst) {
    ofst << "Name = " << name << ". ReleaseDate = "<< releaseDate
         << ". UselessNumber = " << uselessNumber << endl;
}