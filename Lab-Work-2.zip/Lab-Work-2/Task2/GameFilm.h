#ifndef __GameFilm__
#define __GameFilm__

//------------------------------------------------------------------------------
// GameFilm.h - содержит описание игрового фильма
//------------------------------------------------------------------------------

#include <fstream>
using namespace std;

#include "Film.h"

//------------------------------------------------------------------------------
// Игровой фильм
class GameFilm:public Film{
public:
    virtual ~GameFilm(){}
    // Ввод параметров игрового фильма из файла
    virtual void In(ifstream &ifst);
    // Вывод параметров игрового фильма в форматируемый поток
    virtual void Out(ofstream &ofst);
private:
    string director; // Режиссер фильма
};

#endif //__GameFilm__
