#ifndef __DocumentalFilm__
#define __DocumentalFilm__

//------------------------------------------------------------------------------
// DocumentalFilm.h - содержит описание документального фильма
//------------------------------------------------------------------------------

#include <fstream>
using namespace std;

#include "Film.h"

// Документальный фильм
class DocumentalFilm : public Film{
public:
    virtual ~DocumentalFilm(){}
    // Ввод параметров документального фильма из файла
    virtual void In(ifstream &ifst);
    // Вывод параметров документального фильма в форматируемый поток
    virtual void Out(ofstream &ofst);
private:
    int duration; // Длительность фильма
};

#endif //__DocumentalFilm__
