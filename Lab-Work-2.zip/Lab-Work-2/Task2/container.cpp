//------------------------------------------------------------------------------
// container_Constr.cpp - содержит функции обработки контейнера
//------------------------------------------------------------------------------

#include <iostream>
#include "container.h"

//------------------------------------------------------------------------------
// Конструктор контейнера
Container::Container(): len{0} { }
//------------------------------------------------------------------------------
// Деструктор контейнера
Container::~Container() {
    Clear();
}

//------------------------------------------------------------------------------
// Очистка контейнера от элементов (освобождение памяти)
void Container::Clear() {
    for(int i = 0; i < len; i++) {
        delete storage[i];
    }
    len = 0;
}

//------------------------------------------------------------------------------
// Ввод содержимого контейнера из указанного потока
void Container::In(ifstream &ifst) {
    while(!ifst.eof()) {
        if((storage[len] = Film::StaticIn(ifst)) != 0) {
            len++;
        }
    }
}


//------------------------------------------------------------------------------
// Вывод содержимого контейнера в указанный поток
void Container::Out(ofstream &ofst) {
    ofst << "Container contains " << len << " elements.\n";
    for(int i = 0; i < len; i++) {
        ofst << i << ": ";
        storage[i]->Out(ofst);
    }
}

void Container::quicksort(int first, int last) {
    int pivot,j,i;

    if(first<last){
        pivot=first;
        i=first;
        j=last;
        Film* temp;

        while(i<j){
            while(storage[i]->uselessNumber<=storage[pivot]->uselessNumber&&i<last)
                i++;
            while(storage[j]->uselessNumber>storage[pivot]->uselessNumber)
                j--;
            if(i<j){
                temp=storage[i];
                storage[i]=storage[j];
                storage[j]=temp;
            }
        }

        temp=storage[pivot];
        storage[pivot]=storage[j];
        storage[j]=temp;
        quicksort(first,j-1);
        quicksort(j+1,last);

    }
}
