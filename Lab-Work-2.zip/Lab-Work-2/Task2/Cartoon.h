#ifndef __Cartoon__
#define __Cartoon__

//------------------------------------------------------------------------------
// Cartoon.h - содержит описание мультфильма
//------------------------------------------------------------------------------

#include <fstream>
using namespace std;

#include "Film.h"

// Мультфильм
class Cartoon:public Film{
public:
    virtual ~Cartoon(){}
    // Ввод параметров мультфильма из файла
    virtual void In(ifstream &ifst);
    // Вывод параметров мультфильма в форматируемый поток
    virtual void Out(ofstream &ofst);
private:
    enum cartoonType {Painted, Puppet, Plasticine};
    cartoonType type; // Способ создания
};

#endif //__Cartoon__
