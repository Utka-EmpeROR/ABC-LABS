//------------------------------------------------------------------------------
// Cartoon.cpp - содержит функции обработки мультфильма
//------------------------------------------------------------------------------

#include "Cartoon.h"

//------------------------------------------------------------------------------
// Ввод параметров мультфильма из файла
void Cartoon::In(ifstream &ifst) {
    int k;
    ifst >> k;
    switch (k) {
        case 1:
            type = Cartoon::Painted;
            break;
        case 2:
            type = Cartoon::Puppet;
            break;
        case 3:
            type = Cartoon::Plasticine;
            break;
        default:
            break;
    }
}

void  Cartoon::Out(ofstream &ofst) {
    string str;
    switch (type) {
        case Cartoon::Painted:
            str="Painted";
            break;
        case Cartoon::Puppet:
            str="Puppet";
            break;
        case Cartoon::Plasticine:
            str="Plasticine";
            break;
        default:
            str = "Unknown";
            break;
    }
    ofst << "It is Cartoon: type = " << str << ". ";
    Film::Out(ofst);
}
