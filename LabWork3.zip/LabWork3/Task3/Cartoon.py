#----------------------------------------------
from GameFilm import UselessNumber


def Read(game, strArray, i):
    # должно быть как минимум три непрочитанных значения в массиве
    if i >= len(strArray) - 2:
        return 0
    game.append("Cartoon")
    game.append(int(strArray[i]))
    game.append(strArray[i+1])
    cartoontype = int(strArray[i+2])
    if cartoontype==1:
        game.append("Painted")
    elif cartoontype==2:
        game.append("Puppet")
    elif cartoontype==3:
        game.append("Plasticine")
    else: game.append("Unknown")
    i += 3
    #print("Cartoon: year = ", game[1], " name = ", game[2], " type = ", game[3])
    return i

def Print(game):
    print("Cartoon: year = ", game[1], " name = ", game[2], " type = ", game[3], " useless number = ", UselessNumber(game))
    pass

def Write(game, ostream):
    ostream.write("Cartoon: year = {}  name = {}  type = {}  useless number = {}".format(game[1], game[2], game[3], UselessNumber(game)))
    pass