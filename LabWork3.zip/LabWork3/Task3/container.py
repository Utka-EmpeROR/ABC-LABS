#----------------------------------------------
from GameFilm import UselessNumber
from extender import *

def Read(cont, strArray):
    arrayLen = len(strArray)
    i = 0   # Индекс, задающий текущую строку в массиве
    filmNum = 0  # Счетчк фильмов
    while i < arrayLen:
        str = strArray[i]
        key = int(str)   # преобразование в целое
        #print("key = ", key)    # тестовый вывод ключа фильма
        if key == 1: # признак игрового фильма
            i += 1
            game = []
            i = GameFilm.Read(game, strArray, i)   # Заполнение фильма значением и получение следующей позиции
            cont.append(game)      # игроковой фильм поступает в контейнер
        elif key == 2: # признак мультфильма
            i += 1
            cartoon = []
            i = Cartoon.Read(cartoon, strArray, i)   # Заполнение фильма значением и получение следующей позиции
            cont.append(cartoon)      # мультфильм поступает в контейнер
        elif key==3: # признак документального фильма
            i += 1
            doc = []
            i = DocumentalFilm.Read(doc, strArray, i)  # Заполнение фильма значением и получение следующей позиции
            cont.append(doc)  # мультфильм поступает в контейнер
        else:
            # что-то пошло не так. Должен быть известный признак
            # Возврат количества прочитанных фильмов
            return filmNum
        # Количество фильмов увеличивается на 1
        if i == 0:
            return filmNum
        filmNum += 1
    return filmNum

def Print(cont):
    print("Container stores", len(cont), "films:")
    for film in cont:
        if film[0] == "GameFilm":
            GameFilm.Print(film)
        elif film[0] == "Cartoon":
            Cartoon.Print(film)
        elif film[0] == "DocumentalFilm":
            DocumentalFilm.Print(film)
        else:
            print("Incorrect film ", film)
    pass

def Write(cont, ostream):
    ostream.write("Container stores {} films:\n".format(len(cont)))
    for film in cont:
        if film[0] == "GameFilm":
            GameFilm.Write(film, ostream)
        elif film[0] == "Cartoon":
            Cartoon.Write(film, ostream)
        elif film[0] == "DocumentalFilm":
            DocumentalFilm.Write(film, ostream)
        else:
            ostream.write("Incorrect film ")
            ostream.write(film)
        ostream.write("\n")
    pass

def quicksort(cont):

    less = []
    equal = []
    greater = []

    if len(cont) > 1:
        pivot = cont[0]
        for x in cont:
            if UselessNumber(x) < UselessNumber(pivot):
                less.append(x)
            elif UselessNumber(x) == UselessNumber(pivot):
                equal.append(x)
            elif UselessNumber(x) > UselessNumber(pivot):
                greater.append(x)
        return quicksort(less)+equal+quicksort(greater)
    else:
        return cont
