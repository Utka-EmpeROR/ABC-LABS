#----------------------------------------------
from GameFilm import UselessNumber

def Read(game, strArray, i):
    # должно быть как минимум три непрочитанных значения в массиве
    if i >= len(strArray) - 2:
        return 0
    game.append("DocumentalFilm")
    game.append(int(strArray[i]))
    game.append(strArray[i+1])
    game.append(int(strArray[i+2]))
    i += 3
    #print("DocumentalFilm: year = ", game[1], " name = ", game[2], " duration = ", game[3])
    return i

def Print(game):
    print("DocumentalFilm: year = ", game[1], " name = ", game[2], " duration = ", game[3], " useless number = ", UselessNumber(game))
    pass

def Write(game, ostream):
    ostream.write("DocumentalFilm: year = {}  name = {}  duration = {}  useless number = {}".format(game[1], game[2], game[3], UselessNumber(game)))
    pass