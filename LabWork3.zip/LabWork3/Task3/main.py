import sys
import string

import container
from extender import *

#----------------------------------------------
if __name__ == '__main__':
    if len(sys.argv) == 4:
        inputFileName = sys.argv[1]
        outputFileName1 = sys.argv[2]
        outputFileName2 = sys.argv[3]
    elif len(sys.argv) == 3:
        inputFileName  = sys.argv[1]
        outputFileName1 = sys.argv[2]
        outputFileName2 = "output2.txt"
    elif len(sys.argv) == 2:
        inputFileName  = sys.argv[1]
        outputFileName1 = "output1.txt"
        outputFileName2 = "output2.txt"
    elif len(sys.argv) == 1:
        print("Incorrect command line! You must write: python main <inputFileName> [<outputFileName>] [<outputFileName2>]")
        exit()

    ifile = open(inputFileName)
    str = ifile.read()
    ifile.close()

    # Чтение исходного файла, содержащего данные, разделенные пробелами и переводами строки
    #print(str)
    #print("len(str) = ", len(str))

    # Формирование массива строк, содержащего чистые данные в виде массива строк символов.
    strArray = str.replace("\n", " ").split(" ")
    #print(strArray)
    #print("len(strArray) = ", len(strArray))
    #filmNum = ReadArray(strArray)

    print('==> Start')

    cont = []
    filmNum = container.Read(cont, strArray)
    sorted = container.quicksort(cont)

    ofile1 = open(outputFileName1, 'w')
    container.Write(cont, ofile1)
    ofile1.close()
    ofile2 = open(outputFileName2, 'w')
    container.Write(sorted,ofile2)
    ofile2.close()

    print('==> Finish')
