#----------------------------------------------
def Read(game, strArray, i):
    # должно быть как минимум три непрочитанных значения в массиве
    if i >= len(strArray) - 2:
        return 0
    game.append("GameFilm")
    game.append(int(strArray[i]))
    game.append(strArray[i+1])
    game.append(strArray[i+2])
    i += 3
    #print("GameFilm: year = ", game[1], " name = ", game[2], " director = ", game[3])
    return i

def Print(game):
    print("GameFilm: year = ", game[1], " name = ", game[2], " director = ", game[3], " useless number = ", UselessNumber(game))
    pass

def Write(game, ostream):
    ostream.write("GameFilm: year = {}  name = {}  director = {}  useless number = {}".format(game[1], game[2], game[3], UselessNumber(game)))
    pass

def UselessNumber(film):
    return round(film[1]/len(film[2]), 3)
    pass