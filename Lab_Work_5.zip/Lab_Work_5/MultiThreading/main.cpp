#include <iostream>
#include <thread>
#include <string>
#include <random>

/**
 * Метод потоков поиска сокровищ в зонах.
 * @param island Статус зон поиска (исследовано/не исследовано).
 * @param zonesCount Количетво зон поиска.
 * @param num Номер пирата.
 * @param treasures Общее количество найденных сокровищ.
 */
void pirate(bool *island, int zonesCount, int num, int &treasures) {

    // Для безопасного многопоточного рандома.
    thread_local std::random_device rd;
    thread_local std::mt19937 rng(rd());
    std::uniform_int_distribution<int> dist(500, 5000);
    std::uniform_int_distribution<int> chance(0, 100);

    for (int i = 0; i < zonesCount; i++) {
        // Если зона не исследована - исследуем.
        if (!island[i]) {
            island[i] = true;

            // Имитируем процесс поиска сокровищ (случайно время).
            int ii = dist(rng);
            std::this_thread::sleep_for(std::chrono::milliseconds(ii));

            // Раскомментировать строчки ниже для подробного пошагового вывода.
            //std::string res = "Pirate " + std::to_string(num) + " discovered zone " + std::to_string(i) +
            //       " and spend time " + std::to_string(ii);
            //std::cout << res <<std::endl;

            // Устанавливаем 10% шанс нахождения сокровищ в зоне.
            if (chance(rd) < 10) {
                // Раскомментировать строчки ниже для подробного пошагового вывода.
                //res = " Pirate " + std::to_string(num) + " found treasure";
                //std::cout << res <<std::endl;

                // Добавляем сокровище в копилку.
                treasures++;
            }
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        std::cout << "Incorrect input\n Waited: {number of zones} {number of pirates}";
        return 0;
    }
    int n, m;
    try {
        n = std::stoi(argv[1]);
        m = std::stoi((argv[2]));
    } catch (std::exception) {
        std::cout << "Incorrect input\n Waited: {number of zones} {number of pirates}";
        return 0;
    }
    std::cout << "Estimated maximum time to explore the island: " << 5*n/m + 5 << " sec" << std::endl;
    std::cout << "Start" << std::endl;

    // Создаем массив зон поиска сокровищ (чтобы пираты не искали в зонах, в которых уже кто-то был).
    bool *islands = new bool[n];
    int treasures = 0;
    for (int i = 0; i < n; i++) {
        islands[i] = false;
    }

    // Запускаем потоки.
    std::thread **pir = new std::thread *[m];
    for (int i = 0; i < m; i++) {
        pir[i] = new std::thread(pirate, islands, n, i, std::ref(treasures));
    }
    for (int i = 0; i < m; i++) {
        pir[i]->join();
    }
    // Выводим итоговое количество найденных сокровищ.
    std::cout << "Total amount of treasures found: " << treasures << std::endl;
    std::cout << "Stop";
}

