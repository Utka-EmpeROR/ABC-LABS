#ifndef __DocumentalFilm__
#define __DocumentalFilm__

//------------------------------------------------------------------------------
// DocumentalFilm.h - содержит описание документального фильма
//------------------------------------------------------------------------------

#include <fstream>
using namespace std;

// Документальный фильм
struct DocumentalFilm {
    int duration;
};

// Ввод параметров документального фильма из файла
void In(DocumentalFilm &df, ifstream &ifst);

// Вывод параметров документального фильма в форматируемый поток
void Out(DocumentalFilm &df, ofstream &ofst);


#endif //__DocumentalFilm__
