//------------------------------------------------------------------------------
// GameFilm.cpp - содержит функции обработки игрового фильма
//------------------------------------------------------------------------------

#include "GameFilm.h"
#include <string>

//------------------------------------------------------------------------------
// Ввод параметров игрового фильма из потока
void In(GameFilm &gf, ifstream &ifst) {
    string input = "";
    getline(ifst,input);
    if(input.length()>30){
        gf.dirLength=30;
    }
    else{
        gf.dirLength=input.length();
    }
    for(int i=0;i<gf.dirLength;i++) {
        gf.director[i]=input[i];
    }
}

//------------------------------------------------------------------------------
// Вывод параметров игрового фильма в поток
void Out(GameFilm &gf, ofstream &ofst) {
    string output="";
    for(int i=0;i<gf.dirLength;i++){
        output+=gf.director[i];
    }
    ofst << "It is GameFilm: director = "
         << output << ". ";
}
