//------------------------------------------------------------------------------
// Cartoon.cpp - содержит функции обработки мультфильма
//------------------------------------------------------------------------------

#include "Cartoon.h"

//------------------------------------------------------------------------------
// Ввод параметров мультфильма из файла
void In(Cartoon &cf, ifstream &ifst) {
    int k;
    ifst >> k;
    switch (k) {
        case 1:
            cf.type = Cartoon::Painted;
            break;
        case 2:
            cf.type = Cartoon::Puppet;
            break;
        case 3:
            cf.type = Cartoon::Plasticine;
            break;
        default:
            break;
    }
}

//------------------------------------------------------------------------------
// Вывод параметров мультфильма в форматируемый поток
void Out(Cartoon &cf, ofstream &ofst) {
    string str;
    switch (cf.type) {
        case Cartoon::Painted:
            str="Painted";
            break;
        case Cartoon::Puppet:
            str="Puppet";
            break;
        case Cartoon::Plasticine:
            str="Plasticine";
            break;
        default:
            str = "Unknown";
            break;
    }
    ofst << "It is Cartoon: type = " << str << ". ";
}
