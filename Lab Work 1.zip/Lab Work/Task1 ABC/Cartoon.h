#ifndef __Cartoon__
#define __Cartoon__

//------------------------------------------------------------------------------
// Cartoon.h - содержит описание мультфильма
//------------------------------------------------------------------------------

#include <fstream>
using namespace std;

// Мультфильм
struct Cartoon{
    enum cartoonType {Painted, Puppet, Plasticine};
    cartoonType type; // Способ создания
};

// Ввод параметров мультфильма из файла
void In(Cartoon &cf, ifstream &ifst);

// Вывод параметров мультфильма в форматируемый поток
void Out(Cartoon &cf, ofstream &ofst);

#endif //__Cartoon__
