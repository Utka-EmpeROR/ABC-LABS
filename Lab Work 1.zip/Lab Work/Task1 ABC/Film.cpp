//------------------------------------------------------------------------------
// Film.cpp - содержит процедуры связанные с обработкой обобщенного фильма
// и создания произвольного фильма
//------------------------------------------------------------------------------

#include "Film.h"
#include <string>

//------------------------------------------------------------------------------
// Ввод параметров обобщенного фильма из файла
bool In(Film& f, ifstream &ifst) {
    int k,n;
    ifst >> k >> n;
    string name;
    getline(ifst,name);
    switch(k) {
        case 1:
            f.name=name;
            f.releaseDate=n;
            f.uselessNumber = UselessNumber(f);
            f.k = Film::GAME;
            In(f.gf, ifst);
            return true;
        case 2:
            f.name=name;
            f.releaseDate=n;
            f.uselessNumber = UselessNumber(f);
            f.k = Film::CARTOON;
            In(f.cf, ifst);
            return true;
        case 3:
            f.name=name;
            f.releaseDate=n;
            f.uselessNumber = UselessNumber(f);
            f.k = Film::DOCUMENTAL;
            In(f.df, ifst);
            return true;
        default:
            return false;
    }
}

//------------------------------------------------------------------------------
// Вывод параметров текущего фильма в поток
void Out(Film &f, ofstream &ofst) {
    switch(f.k) {
        case Film::GAME:
            Out(f.gf, ofst);
            ofst << "Name = " << f.name << ". ReleaseDate = "<< f.releaseDate
                 << ". UselessNumber = " << f.uselessNumber << endl;
            break;
        case Film::CARTOON:
            Out(f.cf,ofst);
            ofst << "Name = " << f.name << ". ReleaseDate = "<< f.releaseDate
                 << ". UselessNumber = " << f.uselessNumber << endl;
            break;
        case Film::DOCUMENTAL:
            Out(f.df, ofst);
            ofst << "Name = " << f.name << ". ReleaseDate = "<< f.releaseDate
                 << ". UselessNumber = " << f.uselessNumber << endl;
            break;
        default:
            ofst << "Incorrect film!" << endl;
    }
}

double UselessNumber(Film &f){
    return (double)f.releaseDate/(double)f.name.length();
}
