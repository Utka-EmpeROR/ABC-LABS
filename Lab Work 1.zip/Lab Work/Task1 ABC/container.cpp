//------------------------------------------------------------------------------
// container_Constr.cpp - содержит функции обработки контейнера
//------------------------------------------------------------------------------

#include "container.h"

//------------------------------------------------------------------------------
// Инициализация контейнера
void Init(container &c) {
    c.len = 0;
}

//------------------------------------------------------------------------------
// Очистка контейнера от элементов (освобождение памяти)
void Clear(container &c) {
    c.len = 0;
}

//------------------------------------------------------------------------------
// Ввод содержимого контейнера из указанного потока
void In(container &c, ifstream &ifst) {
    while(!ifst.eof()) {
        if(In(c.cont[c.len], ifst)) {
            c.len++;
        }
    }
}

//------------------------------------------------------------------------------
// Вывод содержимого контейнера в указанный поток
void Out(container &c, ofstream &ofst) {
    ofst << "Container contains " << c.len << " elements." << endl;
    for(int i = 0; i < c.len; i++) {
        ofst << i << ": ";
        Out(c.cont[i], ofst);
    }
}

void quicksort(container &c,int first,int last){
    int pivot,j,i;
    Film temp;

    if(first<last){
        pivot=first;
        i=first;
        j=last;

        while(i<j){
            while(c.cont[i].uselessNumber<=c.cont[pivot].uselessNumber&&i<last)
                i++;
            while(c.cont[j].uselessNumber>c.cont[pivot].uselessNumber)
                j--;
            if(i<j){
                temp=c.cont[i];
                c.cont[i]=c.cont[j];
                c.cont[j]=temp;
            }
        }

        temp=c.cont[pivot];
        c.cont[pivot]=c.cont[j];
        c.cont[j]=temp;
        quicksort(c,first,j-1);
        quicksort(c,j+1,last);

    }
}
